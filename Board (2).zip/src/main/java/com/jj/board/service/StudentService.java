package com.jj.board.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jj.board.dao.StudentDAO;
import com.jj.board.model.StudentVO;

@Service
public class StudentService {

	@Autowired
	StudentDAO sdao;
	
	public List<StudentVO> getStudentList()
	{
		return sdao.getStudentList();
	}
}
