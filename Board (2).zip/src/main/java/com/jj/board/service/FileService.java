package com.jj.board.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jj.board.dao.FileDAO;
import com.jj.board.model.FileVO;

@Service
public class FileService {
	@Autowired
	FileDAO fdao;
	
	public void insertFile(List<FileVO> fileList)
	{
		fdao.insertFile(fileList);
	}

	public List<FileVO> getFileListRno(int rno) {
		
		
		return fdao.getFileListRno(rno);
	}
}
