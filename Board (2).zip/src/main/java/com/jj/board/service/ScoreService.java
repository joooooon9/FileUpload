package com.jj.board.service;

public class ScoreService {

}
