package com.jj.board.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jj.board.dao.ReportDAO;
import com.jj.board.model.ReportVO;

@Service
public class ReportService {
	@Autowired
	ReportDAO rdao;

	public void insert(ReportVO rvo) {
		rdao.insert(rvo);
	}
	
	public ReportVO getReportSno(ReportVO rvo) {
		
		return rdao.getReportSno(rvo);
	}

	public ReportVO modifyReport(int rno) {
		
		return rdao.modifyReport(rno);
	}
}
