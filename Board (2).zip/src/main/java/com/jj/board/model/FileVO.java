package com.jj.board.model;

public class FileVO {
	private int rno;			//생기부번호
	private int fno;			//파일번호
	private String bfname;		//파일원본이름
	private String bpname;		//저장된이름
	public int getRno() {
		return rno;
	}
	public void setRno(int rno) {
		this.rno = rno;
	}
	public int getFno() {
		return fno;
	}
	public void setFno(int fno) {
		this.fno = fno;
	}
	public String getBfname() {
		return bfname;
	}
	public void setBfname(String bfname) {
		this.bfname = bfname;
	}
	public String getBpname() {
		return bpname;
	}
	public void setBpname(String bpname) {
		this.bpname = bpname;
	}
	

	
	
}
