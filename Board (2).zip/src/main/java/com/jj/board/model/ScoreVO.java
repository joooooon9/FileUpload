package com.jj.board.model;

public class ScoreVO {

	private int score_no;		//점수리스트번호
	private String title;		//과목이름
	private String sname;		//학생이름
	private int m_score;		//중간점수
	private int f_score;		//기말점수
	private int sno;			//학생번호
	
	
	public int getScore_no() {
		return score_no;
	}
	public String getTitle() {
		return title;
	}
	public String getSname() {
		return sname;
	}
	public int getM_score() {
		return m_score;
	}
	public int getF_score() {
		return f_score;
	}
	public int getSno() {
		return sno;
	}
	public void setScore_no(int score_no) {
		this.score_no = score_no;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public void setM_score(int m_score) {
		this.m_score = m_score;
	}
	public void setF_score(int f_score) {
		this.f_score = f_score;
	}
	public void setSno(int sno) {
		this.sno = sno;
	}
	
	
}
