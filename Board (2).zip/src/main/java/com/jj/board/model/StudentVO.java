package com.jj.board.model;

public class StudentVO {

	private int student_no;		//학생번호
	private String sname;		//학생이름
	private double m_avg;		//중간평균
	private double f_avg;		//기말평균
	private String m_title;		//1학기생기부제목
	private String f_title;		//2학기생기부제목
	
	public int getStudent_no() {
		return student_no;
	}
	public String getSname() {
		return sname;
	}
	public void setStudent_no(int student_no) {
		this.student_no = student_no;
	} 
	public void setSname(String sname) {
		this.sname = sname;
	}
	
	public double getM_avg() {
		return m_avg;
	}
	public void setM_avg(double m_avg) {
		this.m_avg = m_avg;
	}
	public double getF_avg() {
		return f_avg;
	}
	public void setF_avg(double f_avg) {
		this.f_avg = f_avg;
	}
	public String getM_title() {
		return m_title;
	}
	public void setM_title(String m_title) {
		this.m_title = m_title;
	}
	public String getF_title() {
		return f_title;
	}
	public void setF_title(String f_title) {
		this.f_title = f_title;
	}
		
}
