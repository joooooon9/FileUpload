package com.jj.board.dao;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jj.board.model.ReportVO;

@Repository
public class ReportDAO {
    @Autowired
    private SqlSession sqlSession;
    
    private static final String Namespace = "com.jj.board.dao.ReportDAO";
    
    public void insert(ReportVO rvo) {
    	sqlSession.insert(Namespace + ".insert", rvo);
    }
    public ReportVO getReportSno(ReportVO rvo) {
    	
		return sqlSession.selectOne(Namespace + ".getReportSno", rvo);
    }
	public ReportVO modifyReport(int rno) {

		return sqlSession.selectOne(Namespace + ".modifyReport", rno);
	}
}
