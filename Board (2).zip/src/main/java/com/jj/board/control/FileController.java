package com.jj.board.control;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.jj.board.model.FileVO;
import com.jj.board.service.FileService;
import com.jj.board.service.ReportService;

@Controller
@RequestMapping("/file")
public class FileController {
	@Autowired
	FileService fileservice;
    @RequestMapping(value = "/image-upload", method = RequestMethod.POST)
    @ResponseBody
    public String imageUpload(@RequestParam("file") MultipartFile file, HttpServletRequest request) {
    	String uploadPath = request.getSession().getServletContext().getRealPath("/resources/upload/");
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) {
            uploadDir.mkdirs();
        }
        // 원본 파일명에서 확장자 추출
        String originalFilename = file.getOriginalFilename();
        String extension = "";
        if (originalFilename != null && originalFilename.contains(".")) {
            extension = originalFilename.substring(originalFilename.lastIndexOf("."));
        }
        
        // UUID를 이용해 고유한 파일명 생성
        String newFileName = UUID.randomUUID().toString() + extension;
        
        try {
            // 파일 저장 (uploadPath/newFileName 경로에 저장)
            File destFile = new File(uploadDir, newFileName);
            file.transferTo(destFile);
        } catch (Exception e) {
            e.printStackTrace();
            return "error"; // 에러 발생 시 에러 메시지 반환
        }
        
        // 성공적으로 저장되면 저장된 파일명을 반환 (summernote에서 이 값을 받아 이미지 URL을 완성함)
        return newFileName;
    }
    
    @RequestMapping(value = "/flie_upload", method = RequestMethod.GET)
    public String multifile() 
    {
		return "FlieUpload";
    }
    
    //파일업로드하기
    @RequestMapping(value = "/uploadok", method = RequestMethod.POST)
    public String uploadFiles(@RequestParam("files") List<MultipartFile> files, Model model) {
        List<FileVO> fileList = new ArrayList<>();
        for (MultipartFile file : files) {
            if (!file.isEmpty()) {
                String originalFileName = file.getOriginalFilename();
                String savedFileName = UUID.randomUUID().toString() + "_" + originalFileName;
                String savePath = "C:\\Users\\Cellonix\\eclipse-workspace\\Board\\src\\main\\webapp\\resources\\upload\\" + savedFileName; // 저장 경로

                try {
                    // 파일 저장
                    file.transferTo(new File(savePath));

                    // 파일 정보 저장 (DB에 보낼 리스트 생성)
                    FileVO fileVO = new FileVO();
                    fileVO.setBfname(originalFileName);
                    fileVO.setBpname(savedFileName);
                    fileList.add(fileVO);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        // 파일 정보 DB에 저장
        if (!fileList.isEmpty()) {
            fileservice.insertFile(fileList);  // 파일 정보 리스트를 DB로 저장하는 서비스 호출
        }
        model.addAttribute("files", fileList);
        return "redirect:/index.do";
    }
}
