package com.jj.board.control;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.jj.board.model.FileVO;
import com.jj.board.model.ReportVO;
import com.jj.board.model.StudentVO;
import com.jj.board.service.FileService;
import com.jj.board.service.ReportService;
import com.jj.board.service.StudentService;

@Controller
public class ReportController {
	@Autowired
	StudentService studentservice;
	@Autowired
	ReportService reportservice;
	@Autowired
	FileService fileservice;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String defaultPage() {
		return "redirect:index.do";
	}
	// 학생 리스트
	@RequestMapping(value = "/index.do", method = RequestMethod.GET)
	public String Student_list(Model model) {
		List<StudentVO> StudentList = studentservice.getStudentList();
		model.addAttribute("StudentList", StudentList);
		return "index";
	}

	// 1학기 생기부 작성페이지
	@RequestMapping(value = "/repo_write1", method = RequestMethod.GET)
	public String Report_w1() {
		return "repo_write1";
	}
	// 2학기 생기부 작성페이지
	@RequestMapping(value = "/repo_write2", method = RequestMethod.GET)
	public String Report_w2() {
		return "repo_write2";
	}

	// 생기부 작성완료
	@RequestMapping(value = "/reportok", method = RequestMethod.POST)
	public String Report_wOK(ReportVO rvo,@RequestParam("files") List<MultipartFile> files, Model model) {
		
		reportservice.insert(rvo);
		List<FileVO> fileList = new ArrayList<>();
        for (MultipartFile file : files) {
            if (!file.isEmpty()) {
                String originalFileName = file.getOriginalFilename();
                String savedFileName = UUID.randomUUID().toString() + "_" + originalFileName;
                String savePath = "C:\\Users\\Cellonix\\eclipse-workspace\\Board\\src\\main\\webapp\\resources\\upload\\" + savedFileName; // 저장 경로

                try {
                    // 파일 저장
                    file.transferTo(new File(savePath));

                    // 파일 정보 저장 (DB에 보낼 리스트 생성)
                    FileVO fileVO = new FileVO();
                    fileVO.setRno(rvo.getRno());
                    fileVO.setBfname(originalFileName);
                    fileVO.setBpname(savedFileName);
                    fileList.add(fileVO);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        // 파일 정보 DB에 저장
        if (!fileList.isEmpty()) {
            fileservice.insertFile(fileList);  // 파일 정보 리스트를 DB로 저장하는 서비스 호출
        }
        model.addAttribute("files", fileList);
        return "redirect:/index.do";
	}
	
	//생기부 보기
	@RequestMapping(value = "/repo_view", method = RequestMethod.GET)
	public String Repo_View(@RequestParam("student_no") int student_no,@RequestParam("flag") int flag, Model model) {
		ReportVO rvo = new ReportVO();
		rvo.setStudent_no(student_no);
		rvo.setFlag(flag);

		ReportVO report = reportservice.getReportSno(rvo);
		model.addAttribute("report", report);
		//추가해야할것 첨부파일 리스트 보여주기
		int rno = report.getRno();
	
		List<FileVO> file = fileservice.getFileListRno(rno);
		
		model.addAttribute("fileList",file);
		return "repo_view";
	}
	//생기부 수정페이지
	@RequestMapping(value = "/modify", method = RequestMethod.GET)
	public String Repo_Modify(@RequestParam("rno") int rno, Model model) {
		
		ReportVO report = reportservice.modifyReport(rno);
		//첨부파일이 있으면 첨부파일 리스트 보여주기
		model.addAttribute("report", report);
		return "repo_write1"; //modify.jsp만들기
	}
	//생기부 수정완료 페이지
	
}
