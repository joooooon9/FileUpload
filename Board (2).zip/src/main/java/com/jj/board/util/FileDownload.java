package com.jj.board.util;

import org.springframework.stereotype.Component;

@Component
public class FileDownload {

}
